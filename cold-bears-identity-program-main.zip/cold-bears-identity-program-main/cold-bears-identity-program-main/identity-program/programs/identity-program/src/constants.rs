pub const ADMIN_PUBKEY_STR: &str = "FpLbdDnS61viAgJtSXHPKBuvKYRFQ7yc6rzuaLSy1MTc";
pub const TREASURY_PUBKEY_STR: &str = "4reqRtKEqXggb7xAFobTnPpAXtoSi5zEBK8WLL5qyn1B";